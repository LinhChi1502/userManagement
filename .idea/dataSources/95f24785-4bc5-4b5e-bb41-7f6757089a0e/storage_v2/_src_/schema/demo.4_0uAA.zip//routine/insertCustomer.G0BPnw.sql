create
    definer = root@localhost procedure insertCustomer(IN _name varchar(120), IN _email varchar(120),
                                                      IN _country varchar(120))
begin
    insert into users (name, email, country) VALUES (_name, _email, _country);
end;

