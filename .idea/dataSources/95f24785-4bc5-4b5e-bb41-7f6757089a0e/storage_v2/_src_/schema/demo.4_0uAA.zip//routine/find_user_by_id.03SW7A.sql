create
    definer = root@localhost procedure find_user_by_id(IN _id int)
begin
    select * from users
        where id = _id;
end;

